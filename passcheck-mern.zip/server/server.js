require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
app.use(cors());
app.use(express.json());

// ---------- Models ----------
const User = mongoose.model('User', new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true, lowercase: true },
  password: { type: String, required: true },
}));

const Check = mongoose.model('Check', new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  label: { type: String, required: true, trim: true },   // e.g. "Gmail"
  score: { type: Number, required: true, min: 0, max: 100 },
  strength: { type: String, enum: ['Weak', 'Fair', 'Good', 'Strong'], required: true },
  notes: { type: String, default: '' },
}, { timestamps: true }));
// NOTE: the password itself is NEVER stored - only its score.

// ---------- Helpers ----------
const sign = (u) => jwt.sign({ id: u._id }, process.env.JWT_SECRET, { expiresIn: '7d' });

const auth = (req, res, next) => {
  try {
    const token = (req.headers.authorization || '').split(' ')[1];
    req.userId = jwt.verify(token, process.env.JWT_SECRET).id;
    next();
  } catch {
    res.status(401).json({ message: 'Please log in again.' });
  }
};

// ---------- Auth routes ----------
app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password || password.length < 6)
      return res.status(400).json({ message: 'Name, email and a 6+ character password are required.' });
    if (await User.findOne({ email })) return res.status(400).json({ message: 'That email is already registered.' });
    const user = await User.create({ name, email, password: await bcrypt.hash(password, 10) });
    res.status(201).json({ token: sign(user), user: { name: user.name, email: user.email } });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const user = await User.findOne({ email: (req.body.email || '').toLowerCase() });
    if (!user || !(await bcrypt.compare(req.body.password || '', user.password)))
      return res.status(400).json({ message: 'Wrong email or password.' });
    res.json({ token: sign(user), user: { name: user.name, email: user.email } });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ---------- Check history CRUD (protected) ----------
app.get('/api/checks', auth, async (req, res) => {
  res.json(await Check.find({ user: req.userId }).sort({ createdAt: -1 }));
});

app.post('/api/checks', auth, async (req, res) => {
  try {
    const { label, score, strength, notes } = req.body;
    const check = await Check.create({ label, score, strength, notes, user: req.userId });
    res.status(201).json(check);
  } catch (e) { res.status(400).json({ message: e.message }); }
});

app.put('/api/checks/:id', auth, async (req, res) => {
  try {
    const { label, notes } = req.body;
    const check = await Check.findOneAndUpdate(
      { _id: req.params.id, user: req.userId },
      { label, notes },
      { new: true, runValidators: true }
    );
    check ? res.json(check) : res.status(404).json({ message: 'Record not found.' });
  } catch (e) { res.status(400).json({ message: e.message }); }
});

app.delete('/api/checks/:id', auth, async (req, res) => {
  const check = await Check.findOneAndDelete({ _id: req.params.id, user: req.userId });
  check ? res.json({ message: 'Deleted' }) : res.status(404).json({ message: 'Record not found.' });
});

// ---------- Start ----------
mongoose.connect(process.env.MONGO_URI)
  .then(() => {
    console.log('MongoDB connected');
    app.listen(process.env.PORT || 5000, () => console.log('Server running on port ' + (process.env.PORT || 5000)));
  })
  .catch((err) => console.error('MongoDB connection failed:', err.message));
