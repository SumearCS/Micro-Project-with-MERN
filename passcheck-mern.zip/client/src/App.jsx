import { useState } from 'react';
import { Routes, Route, Link, Navigate, useNavigate } from 'react-router-dom';
import Home from './pages/Home.jsx';
import Auth from './pages/Auth.jsx';
import Checker from './pages/Checker.jsx';

export default function App() {
  const [user, setUser] = useState(JSON.parse(localStorage.getItem('user') || 'null'));
  const navigate = useNavigate();

  const login = (data) => {
    localStorage.setItem('token', data.token);
    localStorage.setItem('user', JSON.stringify(data.user));
    setUser(data.user);
    navigate('/checker');
  };

  const logout = () => {
    localStorage.clear();
    setUser(null);
    navigate('/');
  };

  return (
    <>
      <header className="nav">
        <Link to="/" className="brand">PassCheck</Link>
        <nav>
          {user ? (
            <>
              <Link to="/checker">Analyzer</Link>
              <button className="link" onClick={logout}>Log out</button>
            </>
          ) : (
            <>
              <Link to="/login">Log in</Link>
              <Link to="/register" className="btn small">Sign up</Link>
            </>
          )}
        </nav>
      </header>
      <main>
        <Routes>
          <Route path="/" element={<Home user={user} />} />
          <Route path="/login" element={<Auth mode="login" onAuth={login} />} />
          <Route path="/register" element={<Auth mode="register" onAuth={login} />} />
          <Route path="/checker" element={user ? <Checker user={user} /> : <Navigate to="/login" />} />
        </Routes>
      </main>
    </>
  );
}
