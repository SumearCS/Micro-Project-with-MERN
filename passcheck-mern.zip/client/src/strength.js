const COMMON = ['password', '123456', 'qwerty', 'abc123', 'letmein', 'welcome', 'admin', 'iloveyou', '111111'];

export function analyze(pw) {
  if (!pw) return { score: 0, strength: 'Weak', tips: ['Start typing a password to check it.'] };
  const tips = [];
  let score = 0;

  if (pw.length >= 8) score += 20; else tips.push('Use at least 8 characters.');
  if (pw.length >= 12) score += 15; else tips.push('12 or more characters is much stronger.');
  if (/[a-z]/.test(pw)) score += 15; else tips.push('Add lowercase letters.');
  if (/[A-Z]/.test(pw)) score += 15; else tips.push('Add uppercase letters.');
  if (/\d/.test(pw)) score += 15; else tips.push('Add numbers.');
  if (/[^A-Za-z0-9]/.test(pw)) score += 20; else tips.push('Add a symbol such as ! @ # $.');

  if (/(.)\1{2,}/.test(pw)) { score -= 15; tips.push('Avoid repeating the same character.'); }
  if (COMMON.some((c) => pw.toLowerCase().includes(c))) {
    score = Math.min(score, 15);
    tips.push('Avoid common words and patterns.');
  }

  score = Math.max(0, Math.min(100, score));
  const strength = score < 30 ? 'Weak' : score < 60 ? 'Fair' : score < 80 ? 'Good' : 'Strong';
  if (!tips.length) tips.push('Great password. Use a different one for every account.');
  return { score, strength, tips };
}
