import { Link } from 'react-router-dom';

export default function Home({ user }) {
  return (
    <section className="hero">
      <h1>Is your password strong enough?</h1>
      <p>Type a password and see its strength instantly, with tips to improve it. Save the scores to track your accounts. We never store the password itself.</p>
      <Link to={user ? '/checker' : '/register'} className="btn">
        {user ? 'Open the analyzer' : 'Create a free account'}
      </Link>
      <ul className="features">
        <li><b>Analyze</b> length, letters, numbers and symbols</li>
        <li><b>Spot</b> common words and repeated characters</li>
        <li><b>Save</b> scores with a label like "Gmail" and manage them later</li>
      </ul>
    </section>
  );
}
