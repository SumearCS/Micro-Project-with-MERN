import { useEffect, useState } from 'react';
import api from '../api.js';
import { analyze } from '../strength.js';

export default function Checker({ user }) {
  const [pw, setPw] = useState('');
  const [show, setShow] = useState(false);
  const [label, setLabel] = useState('');
  const [records, setRecords] = useState([]);
  const [editId, setEditId] = useState(null);
  const [edit, setEdit] = useState({ label: '', notes: '' });
  const [error, setError] = useState('');

  const result = analyze(pw);

  const load = async () => {
    try {
      const { data } = await api.get('/checks');
      setRecords(data);
    } catch {
      setError('Could not load your history.');
    }
  };
  useEffect(() => { load(); }, []);

  // CREATE - saves only the score, never the password
  const save = async (e) => {
    e.preventDefault();
    if (!pw) return setError('Type a password to analyze first.');
    try {
      await api.post('/checks', { label, score: result.score, strength: result.strength });
      setLabel('');
      setPw('');
      setError('');
      load();
    } catch (err) {
      setError(err.response?.data?.message || 'Could not save the result.');
    }
  };

  // UPDATE
  const saveEdit = async (id) => {
    try {
      await api.put(`/checks/${id}`, edit);
      setEditId(null);
      load();
    } catch (err) {
      setError(err.response?.data?.message || 'Could not update the record.');
    }
  };

  // DELETE
  const remove = async (id) => {
    if (!confirm('Delete this record?')) return;
    await api.delete(`/checks/${id}`);
    load();
  };

  return (
    <>
      <h2>Hi {user.name}</h2>

      <form className="card" onSubmit={save}>
        <h3>Analyze a password</h3>
        {error && <p className="error">{error}</p>}
        <div className="row">
          <input type={show ? 'text' : 'password'} placeholder="Type a password" value={pw}
            onChange={(e) => setPw(e.target.value)} autoComplete="off" />
          <button type="button" className="btn ghost" onClick={() => setShow(!show)}>{show ? 'Hide' : 'Show'}</button>
        </div>

        <div className="meter"><div className={`fill ${result.strength}`} style={{ width: result.score + '%' }} /></div>
        <p><b>{pw ? result.strength : 'No password yet'}</b> <span className="muted">({result.score}/100)</span></p>
        <ul className="tips">{result.tips.map((t) => <li key={t}>{t}</li>)}</ul>

        <input placeholder="Label to save under (e.g. Gmail)" value={label}
          onChange={(e) => setLabel(e.target.value)} required />
        <button className="btn">Save result</button>
        <p className="muted small-text">Only the score and label are saved. The password is never sent or stored.</p>
      </form>

      <h3>Saved results</h3>
      {records.length === 0 ? (
        <p className="muted">Nothing saved yet. Analyze a password and save the result.</p>
      ) : (
        <ul className="list">
          {records.map((r) => (
            <li key={r._id} className="task">
              {editId === r._id ? (
                <div className="grow editbox">
                  <input value={edit.label} onChange={(e) => setEdit({ ...edit, label: e.target.value })} />
                  <input placeholder="Notes" value={edit.notes} onChange={(e) => setEdit({ ...edit, notes: e.target.value })} />
                  <div className="row">
                    <button className="btn small" onClick={() => saveEdit(r._id)}>Save changes</button>
                    <button className="btn small ghost" onClick={() => setEditId(null)}>Cancel</button>
                  </div>
                </div>
              ) : (
                <>
                  <span className={`badge ${r.strength}`}>{r.score}</span>
                  <div className="grow">
                    <strong>{r.label}</strong> <span className="muted">{r.strength}</span>
                    {r.notes && <p>{r.notes}</p>}
                    <p>{new Date(r.createdAt).toLocaleDateString()}</p>
                  </div>
                  <button className="link" onClick={() => { setEditId(r._id); setEdit({ label: r.label, notes: r.notes }); }}>Edit</button>
                  <button className="link danger" onClick={() => remove(r._id)}>Delete</button>
                </>
              )}
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
