import { useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../api.js';
import { analyze } from '../strength.js';

export default function Auth({ mode, onAuth }) {
  const isLogin = mode === 'login';
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [error, setError] = useState('');

  const change = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    // on sign-up, only accept a Good or Strong password
    if (!isLogin && analyze(form.password).score < 60) {
      return setError('Choose a stronger password (score 60+). Try the analyzer tips: longer, mixed case, numbers and a symbol.');
    }
    try {
      const { data } = await api.post(`/auth/${mode}`, form);
      onAuth(data);
    } catch (err) {
      setError(err.response?.data?.message || 'Could not reach the server.');
    }
  };

  const live = analyze(form.password);

  return (
    <form className="card auth" onSubmit={submit}>
      <h2>{isLogin ? 'Log in' : 'Create your account'}</h2>
      {error && <p className="error">{error}</p>}
      {!isLogin && (
        <label>Name<input name="name" value={form.name} onChange={change} required /></label>
      )}
      <label>Email<input type="email" name="email" value={form.email} onChange={change} required /></label>
      <label>Password<input type="password" name="password" value={form.password} onChange={change} minLength={6} required /></label>
      {!isLogin && form.password && (
        <div className="meter"><div className={`fill ${live.strength}`} style={{ width: live.score + '%' }} /></div>
      )}
      <button className="btn">{isLogin ? 'Log in' : 'Sign up'}</button>
      <p className="muted">
        {isLogin ? <>New here? <Link to="/register">Sign up</Link></> : <>Have an account? <Link to="/login">Log in</Link></>}
      </p>
    </form>
  );
}
