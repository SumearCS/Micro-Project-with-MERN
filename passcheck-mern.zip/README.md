# PassCheck - Password Strength Analyzer (MERN)

Stack: MongoDB, Express.js, React (Vite), Node.js. Auth: JWT + bcrypt.
The analyzer runs in the browser. Only the score + label are saved, never the password.

## Setup
1. Backend
   cd server
   cp .env.example .env
   npm install
   npm run dev        -> http://localhost:5000
2. Frontend (second terminal)
   cd client
   npm install
   npm run dev        -> http://localhost:5173

## API
POST /api/auth/register   POST /api/auth/login
GET /api/checks   POST /api/checks   PUT /api/checks/:id   DELETE /api/checks/:id   (JWT required)
